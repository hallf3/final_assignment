#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Adds classes for students to a list
 * 
 * @param course a list of courses
 * @param student a list of students 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));  //starts a list of courses a student takes
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //adds courses to the already existing list of courses a student is taking
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the name of the student, their code, and the total number of students.
 * 
 * @param course information about each course. array of student names, array of codes, list of students, total number of students.
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //prints each students name, id, grades, and average in a loop
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Sorts the list of students for the one with the highest grade average 
 * 
 * @param course information about each course. array of student names, array of codes, list of students, total number of students.
 * @return Student* The student with the highst average. 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  //Sorts the student's averages to find the highest average int
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * Finds which classes a student has a grade at least 50, which is the passing grade.
 * 
 * @param course information about each course. array of student names, array of codes, list of students, total number of students.
 * @param total_passing the number of students that are passing the course as an int
 * @return passing returns the number, int, of students that pass the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //sees if a students average is >=50 to count the number of students passing 
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //starts a list of students who are passing a course

  int j = 0;

  //sees if a students average is >=50 to count the number of students passing 
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}